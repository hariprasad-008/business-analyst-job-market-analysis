"""
INFO 5006 Business Intelligence - Assignment 1
Individual variable-level data quality assessment and data exploration
Author: Maria Hasan

Purpose
-------
Runs quantitative variable-level data-quality checks and exploratory analysis
on the group's Iteration-1 handoff dataset (BA_US_Variable_DQA_Handoff.csv),
which holds the 8,610-record refined United States Business Analyst
population BEFORE the job_title / job_skills cleaning that produced the
"Cleaned Dataset" files. This script produces the exact figures quoted in
the individual report (Section 3 - Variable-Level Assessment, and the
"Result of exploring the data" section) and saves supporting charts/tables.

Inputs (relative to the assignment root folder):
  BA_US_Variable_DQA_Handoff.csv                 (raw pre-cleaning handoff, no header)
  Cleaned Dataset/ba_refined_postings_final.csv   (cleaned postings, for cross-check)
  Cleaned Dataset/ba_refined_skills_final.csv     (cleaned long-format skills, for cross-check)

Outputs:
  Maria_Hasan_Individual/analysis/outputs/*.png   (charts)
  Maria_Hasan_Individual/analysis/outputs/*.csv   (summary tables quoted in the report)
"""

import re
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

pd.set_option("display.max_columns", None)

ROOT = ".."  # run from Maria_Hasan_Individual/analysis
HANDOFF_PATH = "../../BA_US_Variable_DQA_Handoff.csv"
POSTINGS_FINAL_PATH = "../../Cleaned Dataset/ba_refined_postings_final.csv"
SKILLS_FINAL_PATH = "../../Cleaned Dataset/ba_refined_skills_final.csv"
OUT = "outputs/"

COLS = [
    "job_link", "job_title", "company", "job_location",
    "search_country", "first_seen", "job_skills", "job_summary",
]

# Palette (brand-neutral, colour-blind safe, consistent across charts)
NAVY = "#1F3A5F"
TEAL = "#2E7D8C"
GREY = "#8A94A3"
BG_GREY = "#EEF1F5"


def pct(n, d):
    return 0.0 if d == 0 else round(100 * n / d, 2)


def load_handoff():
    df = pd.read_csv(HANDOFF_PATH, header=None, names=COLS, encoding="utf-8-sig", low_memory=False)
    return df


def completeness_table(df):
    rows = []
    total = len(df)
    for c in COLS:
        s = df[c]
        null_n = int(s.isna().sum())
        empty_n = int((s.fillna("").astype(str).str.strip() == "").sum()) - null_n
        empty_n = max(empty_n, 0)
        populated = total - null_n - empty_n
        rows.append({
            "variable": c,
            "populated": populated,
            "null": null_n,
            "empty_string": empty_n,
            "complete_pct": pct(populated, total),
            "distinct_values": int(s.nunique(dropna=True)),
        })
    out = pd.DataFrame(rows)
    out.to_csv(OUT + "table_completeness_summary.csv", index=False)
    return out


def chart_completeness(comp):
    fig, ax = plt.subplots(figsize=(8, 4.5))
    order = comp.sort_values("complete_pct")
    bars = ax.barh(order["variable"], order["complete_pct"], color=NAVY)
    ax.set_xlim(0, 105)
    ax.set_xlabel("Complete (%)")
    ax.set_title("Completeness by variable - handoff population (n = 8,610)")
    for b, v in zip(bars, order["complete_pct"]):
        ax.text(v + 1, b.get_y() + b.get_height() / 2, f"{v:.2f}%", va="center", fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_completeness.png", dpi=150)
    plt.close(fig)


def analyse_job_link(df):
    total = len(df)
    distinct = df["job_link"].nunique()
    dupes = total - distinct
    return {"total": total, "distinct": distinct, "duplicate_rows": dupes}


def analyse_job_title(df):
    s = df["job_title"].fillna("").astype(str).str.strip()
    total = len(s)
    distinct = s[s != ""].nunique()
    vc = s[s != ""].value_counts()
    one_off = int((vc == 1).sum())
    top15 = vc.head(15)
    top15.to_csv(OUT + "table_top15_job_titles_raw.csv", header=["count"])

    fig, ax = plt.subplots(figsize=(8, 5))
    order = top15.sort_values()
    ax.barh(order.index.astype(str), order.values, color=NAVY)
    ax.set_xlabel("Number of advertisements")
    ax.set_title("Top 15 raw job titles - handoff population (n = 8,610)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_top15_job_titles.png", dpi=150)
    plt.close(fig)

    lengths = s[s != ""].str.split().str.len()
    return {
        "distinct_titles": int(distinct),
        "one_off_titles": one_off,
        "one_off_pct": pct(one_off, distinct),
        "median_words": float(lengths.median()),
        "max_words": int(lengths.max()),
        "top1_title": top15.index[0],
        "top1_count": int(top15.iloc[0]),
        "top1_pct": pct(int(top15.iloc[0]), total),
    }


def analyse_company(df):
    s = df["company"].fillna("").astype(str).str.strip()
    total = len(s)
    blank = int((s == "").sum())
    distinct = s[s != ""].nunique()
    vc = s[s != ""].value_counts()
    top10 = vc.head(10)
    top10.to_csv(OUT + "table_top10_companies.csv", header=["count"])
    generic_terms = {"confidential", "n/a", "na", "undisclosed", "-", "company name"}
    generic_hits = int(s.str.lower().isin(generic_terms).sum())
    return {
        "blank": blank,
        "blank_pct": pct(blank, total),
        "distinct": distinct,
        "top1_company": top10.index[0],
        "top1_count": int(top10.iloc[0]),
        "top1_pct": pct(int(top10.iloc[0]), total),
        "generic_placeholder_rows": generic_hits,
    }


LOC_PATTERN = re.compile(r"^[A-Za-z .'\-]+,\s*[A-Z]{2}$")


def analyse_job_location(df):
    s = df["job_location"].fillna("").astype(str).str.strip()
    total = len(s)
    missing = int((s == "").sum())
    distinct = s[s != ""].nunique()
    valid_pattern = s.apply(lambda x: bool(LOC_PATTERN.match(x)) if x else False)
    valid_n = int(valid_pattern.sum())
    invalid_examples = s[(~valid_pattern) & (s != "")].value_counts().head(10)
    invalid_examples.to_csv(OUT + "table_job_location_invalid_examples.csv", header=["count"])

    vc = s[s != ""].value_counts()
    top15 = vc.head(15)
    top15.to_csv(OUT + "table_top15_job_locations_raw.csv", header=["count"])

    fig, ax = plt.subplots(figsize=(8, 5))
    order = top15.sort_values()
    ax.barh(order.index.astype(str), order.values, color=TEAL)
    ax.set_xlabel("Number of advertisements")
    ax.set_title("Top 15 raw job_location values - handoff population (n = 8,610)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_top15_locations.png", dpi=150)
    plt.close(fig)

    # State-level aggregation using the trailing 2-letter token when the pattern matches
    state = s.where(valid_pattern).str.extract(r",\s*([A-Z]{2})$")[0]
    state_vc = state.value_counts()
    state_vc.head(20).to_csv(OUT + "table_top20_states_from_valid_pattern.csv", header=["count"])

    return {
        "missing": missing,
        "missing_pct": pct(missing, total),
        "distinct_raw": distinct,
        "matches_city_state_pattern": valid_n,
        "matches_pattern_pct": pct(valid_n, total),
        "does_not_match_pattern": total - missing - valid_n,
        "does_not_match_pattern_pct": pct(total - missing - valid_n, total),
        "distinct_states_from_valid_pattern": int(state_vc.shape[0]),
        "top1_state": state_vc.index[0] if len(state_vc) else None,
        "top1_state_n": int(state_vc.iloc[0]) if len(state_vc) else 0,
    }


def analyse_search_country(df):
    vc = df["search_country"].fillna("").astype(str).str.strip().value_counts()
    return {"distinct_values": int(vc.shape[0]), "value_counts": vc.to_dict()}


def analyse_first_seen(df):
    s = pd.to_datetime(df["first_seen"], errors="coerce")
    total = len(s)
    invalid = int(s.isna().sum())
    valid = s.dropna()
    by_day = valid.dt.date.value_counts().sort_index()
    by_day.to_csv(OUT + "table_first_seen_by_day.csv", header=["count"])

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(by_day.index.astype(str), by_day.values, color=NAVY)
    ax.set_ylabel("Number of advertisements")
    ax.set_title("first_seen collection-date distribution - handoff population")
    ax.spines[["top", "right"]].set_visible(False)
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    fig.savefig(OUT + "chart_first_seen_by_day.png", dpi=150)
    plt.close(fig)

    return {
        "invalid": invalid,
        "invalid_pct": pct(invalid, total),
        "min_date": str(valid.min().date()) if len(valid) else None,
        "max_date": str(valid.max().date()) if len(valid) else None,
        "distinct_dates": int(valid.dt.date.nunique()),
    }


def analyse_job_skills(df):
    s = df["job_skills"].fillna("").astype(str)
    total = len(s)
    blank = int((s.str.strip() == "").sum())
    populated = total - blank

    split = s[s.str.strip() != ""].apply(lambda x: [t.strip() for t in x.split(",") if t.strip() != ""])
    counts_per_posting = split.apply(len)

    all_terms = [t for lst in split for t in lst]
    raw_distinct = len(set(t.lower() for t in all_terms))

    vc = pd.Series(all_terms).str.lower().value_counts()
    top15 = vc.head(15)
    top15.to_csv(OUT + "table_top15_raw_skill_terms.csv", header=["count"])

    fig, ax = plt.subplots(figsize=(8, 5))
    order = top15.sort_values()
    ax.barh(order.index.astype(str), order.values, color=NAVY)
    ax.set_xlabel("Number of advertisements")
    ax.set_title("Top 15 raw extracted skill/requirement terms (pre-normalisation, n = 8,610)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_top15_raw_skill_terms.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.hist(counts_per_posting, bins=range(0, counts_per_posting.max() + 2), color=TEAL, edgecolor="white")
    ax.set_xlabel("Extracted terms per advertisement")
    ax.set_ylabel("Number of advertisements")
    ax.set_title("Distribution of extracted job_skills terms per advertisement")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_skills_per_posting_hist.png", dpi=150)
    plt.close(fig)

    # noise proxy: terms that look like sentence fragments rather than skill labels
    # (more than 5 whitespace-separated words -> likely a mis-split description fragment)
    long_terms = [t for t in all_terms if len(t.split()) > 5]

    return {
        "blank": blank,
        "blank_pct": pct(blank, total),
        "populated": populated,
        "median_terms_per_posting": float(counts_per_posting.median()),
        "min_terms": int(counts_per_posting.min()) if len(counts_per_posting) else 0,
        "max_terms": int(counts_per_posting.max()) if len(counts_per_posting) else 0,
        "total_terms": len(all_terms),
        "raw_distinct_terms": raw_distinct,
        "long_fragment_terms": len(long_terms),
        "long_fragment_pct_of_terms": pct(len(long_terms), len(all_terms)),
        "top1_term": top15.index[0],
        "top1_term_n": int(top15.iloc[0]),
        "top1_term_pct": pct(int(top15.iloc[0]), total),
    }


def analyse_job_summary(df):
    s = df["job_summary"].fillna("").astype(str)
    total = len(s)
    blank = int((s.str.strip() == "").sum())
    populated = total - blank
    words = s[s.str.strip() != ""].str.split().str.len()
    boilerplate = int(s.str.contains("Show more Show less", regex=False).sum())
    dollar = int(s.str.contains(r"\$\d", regex=True).sum())
    return {
        "blank": blank,
        "blank_pct": pct(blank, total),
        "populated": populated,
        "median_words": float(words.median()) if len(words) else 0,
        "min_words": int(words.min()) if len(words) else 0,
        "max_words": int(words.max()) if len(words) else 0,
        "boilerplate_rows": boilerplate,
        "boilerplate_pct": pct(boilerplate, total),
        "rows_with_dollar_figure": dollar,
        "rows_with_dollar_figure_pct": pct(dollar, total),
    }


def duplicate_title_company_location(df):
    key = (
        df["job_title"].fillna("").astype(str).str.strip().str.lower() + "|" +
        df["company"].fillna("").astype(str).str.strip().str.lower() + "|" +
        df["job_location"].fillna("").astype(str).str.strip().str.lower()
    )
    total = len(df)
    vc = key.value_counts()
    repeated_groups = int((vc > 1).sum())
    rows_in_repeated_groups = int(vc[vc > 1].sum())
    distinct_after_dedup = int(vc.shape[0])
    return {
        "total": total,
        "distinct_combinations": distinct_after_dedup,
        "repeated_combinations": repeated_groups,
        "rows_in_repeated_combinations": rows_in_repeated_groups,
        "rows_in_repeated_combinations_pct": pct(rows_in_repeated_groups, total),
        "excess_rows_if_deduped_to_one_each": rows_in_repeated_groups - repeated_groups,
    }


def cross_check_cleaned_files(df):
    handoff_links = set(df["job_link"])
    postings_final = pd.read_csv(POSTINGS_FINAL_PATH)
    skills_final = pd.read_csv(SKILLS_FINAL_PATH)

    postings_links = set(postings_final["job_link"])
    skills_links = set(skills_final["job_link"])

    in_handoff_not_in_final_postings = handoff_links - postings_links
    in_final_postings_not_in_handoff = postings_links - handoff_links

    postings_with_skills_rows = skills_links & postings_links
    postings_without_any_skill_row = postings_links - skills_links

    skills_per_job = skills_final.groupby("job_link").size()

    result = {
        "handoff_n": len(handoff_links),
        "postings_final_n": len(postings_links),
        "skills_final_rows": len(skills_final),
        "skills_final_distinct_jobs": len(skills_links),
        "handoff_minus_postings_final": len(in_handoff_not_in_final_postings),
        "postings_final_minus_handoff": len(in_final_postings_not_in_handoff),
        "postings_final_without_any_cleaned_skill_row": len(postings_without_any_skill_row),
        "postings_final_without_any_cleaned_skill_row_pct": pct(len(postings_without_any_skill_row), len(postings_links)),
        "median_cleaned_skills_per_job": float(skills_per_job.median()),
        "min_cleaned_skills_per_job": int(skills_per_job.min()),
        "max_cleaned_skills_per_job": int(skills_per_job.max()),
    }
    return result


def role_category_exploration():
    postings_final = pd.read_csv(POSTINGS_FINAL_PATH)
    vc = postings_final["role_category"].value_counts()
    vc.to_csv(OUT + "table_role_category_distribution.csv", header=["count"])

    fig, ax = plt.subplots(figsize=(8, 5))
    order = vc.sort_values()
    ax.barh(order.index.astype(str), order.values, color=NAVY)
    ax.set_xlabel("Number of advertisements")
    ax.set_title("Cleaned role_category distribution (n = 8,610)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_role_category_distribution.png", dpi=150)
    plt.close(fig)

    return vc.to_dict()


def normalised_skill_exploration():
    skills_final = pd.read_csv(SKILLS_FINAL_PATH)
    vc = skills_final["job_skills_normalized"].value_counts()
    total_jobs = skills_final["job_link"].nunique()
    top15 = vc.head(15)
    top15_pct = (top15 / total_jobs * 100).round(2)
    out = pd.DataFrame({"count": top15, "pct_of_jobs": top15_pct})
    out.to_csv(OUT + "table_top15_normalised_skills.csv")

    fig, ax = plt.subplots(figsize=(8, 5))
    order = top15.sort_values()
    ax.barh(order.index.astype(str), order.values, color=TEAL)
    ax.set_xlabel("Number of advertisements")
    ax.set_title("Top 15 normalised complementary skills (n = 8,610 postings)")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT + "chart_top15_normalised_skills.png", dpi=150)
    plt.close(fig)

    return out


def main():
    df = load_handoff()
    print("Loaded handoff:", df.shape)

    comp = completeness_table(df)
    chart_completeness(comp)
    print("\n== Completeness ==\n", comp)

    r_link = analyse_job_link(df)
    print("\n== job_link ==\n", r_link)

    r_title = analyse_job_title(df)
    print("\n== job_title ==\n", r_title)

    r_company = analyse_company(df)
    print("\n== company ==\n", r_company)

    r_loc = analyse_job_location(df)
    print("\n== job_location ==\n", r_loc)

    r_country = analyse_search_country(df)
    print("\n== search_country ==\n", r_country)

    r_seen = analyse_first_seen(df)
    print("\n== first_seen ==\n", r_seen)

    r_skills = analyse_job_skills(df)
    print("\n== job_skills (raw) ==\n", r_skills)

    r_summary = analyse_job_summary(df)
    print("\n== job_summary ==\n", r_summary)

    r_dupe = duplicate_title_company_location(df)
    print("\n== duplicate title+company+location (independent check) ==\n", r_dupe)

    r_cross = cross_check_cleaned_files(df)
    print("\n== cross-check vs Cleaned Dataset ==\n", r_cross)

    r_role = role_category_exploration()
    print("\n== role_category (cleaned) ==\n", r_role)

    r_norm_skills = normalised_skill_exploration()
    print("\n== top normalised skills (cleaned) ==\n", r_norm_skills)

    print("\nAll tables and charts written to", OUT)


if __name__ == "__main__":
    main()
