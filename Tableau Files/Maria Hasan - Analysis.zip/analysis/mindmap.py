"""
Renders Maria Hasan's individual mind map for the Management Analyst job-market problem
(Assignment 1 - individual preparation for the group discussion) as a PNG,
using matplotlib only (no external graph-drawing dependency).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import textwrap

NAVY = "#1F3A5F"
TEAL = "#2E7D8C"
AMBER = "#C77D26"
PLUM = "#6B4C82"
GREEN = "#3F7A4E"
GREY = "#5B6472"
BG = "#F7F8FA"

fig, ax = plt.subplots(figsize=(15, 11.5))
ax.set_xlim(0, 15)
ax.set_ylim(-1.0, 11.2)
ax.axis("off")
fig.patch.set_facecolor("white")

CENTER = (7.5, 5.85)


def wrap(t, w=26):
    return "\n".join(textwrap.wrap(t, w))


def node(xy, text, color, w, h, fontsize=10.5, weight="bold", fc="white"):
    x, y = xy
    box = FancyBboxPatch(
        (x - w / 2, y - h / 2), w, h,
        boxstyle="round,pad=0.06,rounding_size=0.12",
        linewidth=1.6, edgecolor=color, facecolor=fc, zorder=3,
    )
    ax.add_patch(box)
    ax.text(x, y, text, ha="center", va="center", fontsize=fontsize,
             fontweight=weight, color=color, zorder=4, linespacing=1.3)
    return (x, y, w, h)


def leaf(xy, text, color, fontsize=9.2):
    x, y = xy
    ax.text(x, y, "• " + text, ha="left", va="center", fontsize=fontsize,
             color="#2B2F36", zorder=4)


def connect(a, b, color):
    con = ConnectionPatch(a, b, "data", "data", arrowstyle="-", lw=1.4,
                           color=color, zorder=2, alpha=0.85)
    ax.add_artist(con)


# Center node
node(CENTER, wrap("What does the U.S. job market expect\nof a Management Analyst?\n(Business Analyst postings, LinkedIn, Jan 2024)", 32),
     NAVY, 3.9, 1.6, fontsize=11.5, fc="#EAF0F6")

branches = [
    {
        "label": "Business\nUnderstanding", "color": NAVY, "pos": (2.4, 9.9),
        "leaves": [
            "Client: US consulting firm advising on the Management Analyst job market",
            "Stakeholders: employers, job-seekers, recruiters/HR, career-changers, training providers",
            "Occupational lens: O*NET/BLS map 'Business Analyst' titles to SOC 13-1111.00, "
            "Management Analysts",
        ],
    },
    {
        "label": "Data\nSources", "color": TEAL, "pos": (12.8, 9.9),
        "leaves": [
            "Kaggle: 1.3M LinkedIn Jobs & Skills (2024) - asaniczka",
            "postings + job_skills + job_summary, joined on job_link",
            "Context: BLS OOH and O*NET profiles for Management Analysts (13-1111.00); "
            "consultant-competency literature",
        ],
    },
    {
        "label": "Candidate\nAnalytical\nQuestions", "color": GREEN, "pos": (13.4, 4.4),
        "leaves": [
            "Which job roles/titles require Management Analyst capability?",
            "Which complementary skills accompany that capability, and how do they compare "
            "to O*NET's Management Analyst skill/technology profile?",
            "Where are these advertisements geographically concentrated?",
            "(parked: job type, job level, employer type, cross-country)",
        ],
    },
    {
        "label": "Data Quality\nConcerns", "color": AMBER, "pos": (9.9, 0.0),
        "leaves": [
            "Scraped snapshot, not a census - 6-day window (12-17 Jan 2024)",
            "search_city/search_country describe the query, not the job",
            "job_skills is NER-extracted free text: gaps + spelling variants",
            "job_title highly fragmented (~85% of titles used once)",
        ],
    },
    {
        "label": "Iteration 1\nScope &\nConstraints", "color": PLUM, "pos": (1.9, 0.6),
        "leaves": [
            "Refined U.S. Management Analyst population: 8,610 advertisements",
            "In scope: job roles, complementary skills, geography",
            "Out of scope: salary, seniority, employer, cross-country",
            "First iteration only - recommend next steps, no solution yet",
        ],
    },
]

for b in branches:
    node(b["pos"], b["label"], b["color"], 2.6, 1.25, fontsize=11.5, fc="white")
    connect(CENTER, b["pos"], b["color"])
    bx, by = b["pos"]
    dx = -1 if bx < 7.5 else 1
    lx = bx + dx * 2.55
    LINE_H, GAP = 0.20, 0.20
    wrapped = [textwrap.wrap(lf, 34) for lf in b["leaves"]]
    n_lines = [len(w) for w in wrapped]
    total_h = sum(n * LINE_H for n in n_lines) + GAP * (len(wrapped) - 1)
    ly = by + total_h / 2
    ha = "right" if dx < 0 else "left"
    for w, n in zip(wrapped, n_lines):
        block_h = n * LINE_H
        cy = ly - block_h / 2
        text = "\n".join(w)
        ax.text(lx, cy, ("• " + text) if dx > 0 else (text + " •"),
                 ha=ha, va="center", fontsize=8.7, color="#2B2F36", zorder=4, linespacing=1.25)
        ly -= block_h + GAP

ax.text(7.5, 10.9, "Individual mind map — Maria Hasan — INFO 5006 Business Intelligence, Assignment 1",
        ha="center", fontsize=11.5, color=GREY)

fig.tight_layout()
fig.savefig("outputs/individual_mind_map.png", dpi=170, facecolor="white")
print("saved outputs/individual_mind_map.png")
